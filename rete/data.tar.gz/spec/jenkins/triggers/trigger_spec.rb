require 'spec_helper'

describe Jenkins::Triggers::Trigger do
  it "lives" do
    expect(subject).not_to be_nil
  end
end
