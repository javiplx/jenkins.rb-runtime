require 'spec_helper'

describe Jenkins::CLI::Command do
  it 'works and is testable *cough* @kohsuke *cough*'
end
