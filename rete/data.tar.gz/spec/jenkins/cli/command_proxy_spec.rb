require 'spec_helper'

describe Jenkins::CLI::CommandProxy do
  it 'works and is testable *cough* @kohsuke *cough*'
end
