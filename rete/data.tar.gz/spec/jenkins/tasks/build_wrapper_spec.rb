require 'spec_helper'

describe Jenkins::Tasks::BuildWrapper do
  it "lives" do
    expect(subject).not_to be_nil
  end
end
