
# Jenkins Plugin Runtime

This gem provides the glue between the native Jenkins runtime
which is implemented in Java, and an idiomatic API that allows
for development with a Ruby 'feel'

If you're interested in developing actual plugin, see the
[plugin development tools][1]

[1]:https://github.com/jenkinsci/jpi.rb

