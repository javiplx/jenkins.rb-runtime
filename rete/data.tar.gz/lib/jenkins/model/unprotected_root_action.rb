
module Jenkins
  module Model
    class UnprotectedRootAction
      include Jenkins::Model::Action
    end
  end
end
