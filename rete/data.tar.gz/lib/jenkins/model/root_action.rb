
module Jenkins
  module Model
    class RootAction
      include Jenkins::Model::Action
    end
  end
end
