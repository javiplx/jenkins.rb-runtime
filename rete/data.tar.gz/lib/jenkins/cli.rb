module Jenkins::CLI
  require 'jenkins/cli/command'
  require 'jenkins/cli/command_proxy'
end