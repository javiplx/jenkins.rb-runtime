module Jenkins
  class Plugin
    module Runtime
      VERSION = "0.2.4"
    end
  end
end
