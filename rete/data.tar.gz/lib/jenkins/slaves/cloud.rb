
module Jenkins
  module Slaves
    class Cloud
      include Jenkins::Model

    end
  end
end
