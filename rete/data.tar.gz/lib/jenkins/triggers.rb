module Jenkins::Triggers
  require 'jenkins/triggers/trigger_descriptor'
  require 'jenkins/triggers/trigger'
  require 'jenkins/triggers/trigger_proxy'
end